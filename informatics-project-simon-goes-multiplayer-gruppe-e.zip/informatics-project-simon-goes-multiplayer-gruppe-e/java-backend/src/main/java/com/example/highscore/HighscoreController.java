package com.example.highscore;

public class HighscoreController {

}
