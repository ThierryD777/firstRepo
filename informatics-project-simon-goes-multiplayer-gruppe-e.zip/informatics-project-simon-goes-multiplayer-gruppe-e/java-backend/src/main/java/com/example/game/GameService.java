package com.example.game;

public class GameService {

}
