package com.example.highscore;

public class HighscoreRepository {

}
