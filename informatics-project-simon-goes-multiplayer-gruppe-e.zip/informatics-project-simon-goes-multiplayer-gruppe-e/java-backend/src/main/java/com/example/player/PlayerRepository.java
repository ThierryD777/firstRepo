package com.example.player;

public class PlayerRepository {

}
