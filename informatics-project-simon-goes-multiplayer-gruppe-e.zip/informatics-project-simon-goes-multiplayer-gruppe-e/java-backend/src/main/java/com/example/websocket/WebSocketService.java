package com.example.websocket;

import io.vertx.core.json.JsonObject;

public class WebSocketService {

    public static void handleMessage(String clientId, JsonObject message, WebSocketVerticle wsVerticle) {
        String action = message.getString("action");

        switch (action) {
            case "startGame":
                handleStartGame(wsVerticle);
                break;
            case "playerReady":
                handlePlayerReady(message, wsVerticle);
                break;
            case "endGame":
                handleEndGame(wsVerticle);
                break;
            default:
                System.out.println("Unknown action: " + action);
        }
    }

    private static void handleStartGame(WebSocketVerticle wsVerticle) {
        //GameService.startGame();
        JsonObject response = new JsonObject().put("event", "gameStarted").put("message", "Game has started!");
        wsVerticle.broadcast(response);
    }

    private static void handlePlayerReady(JsonObject message, WebSocketVerticle wsVerticle) {
        String uid = message.getString("uid");
        //PlayerService.setPlayerReady(uid, true);
        JsonObject response = new JsonObject().put("event", "playerReady").put("uid", uid);
        wsVerticle.broadcast(response);
    }

    private static void handleEndGame(WebSocketVerticle wsVerticle) {
        //GameService.endGame();
        JsonObject response = new JsonObject().put("event", "gameEnded").put("message", "Game has ended!");
        wsVerticle.broadcast(response);
    }
}
