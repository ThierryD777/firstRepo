package com.example.websocket;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.http.ServerWebSocket;
import io.vertx.core.json.JsonObject;

public class WebSocketVerticle extends AbstractVerticle {

    private static final Logger logger = LoggerFactory.getLogger(WebSocketVerticle.class);

    private final Map<String, ServerWebSocket> clients = new ConcurrentHashMap<>();

    @Override
    public void start() {
        vertx.createHttpServer()
                .webSocketHandler(this::handleWebSocket)
                .listen(8888, result -> {
                    if (result.succeeded()) {
                        logger.info("WebSocket server started on port 8888");
                    } else {
                        logger.error("Failed to start WebSocket server");
                    }
                });
    }

    private void handleWebSocket(ServerWebSocket ws) {
        String clientId = ws.remoteAddress().toString();
        clients.put(clientId, ws);
        logger.info("New client connected: {}", clientId);

        // Handle messages
        ws.handler(buffer -> {
            JsonObject message = buffer.toJsonObject();
            WebSocketService.handleMessage(clientId, message, this);
        });

        // Handle close event
        ws.closeHandler(event -> {
            clients.remove(clientId);
            logger.info("Client disconnected: {}", clientId);
        });
    }

    public void broadcast(JsonObject message) {
        for (ServerWebSocket client : clients.values()) {
            client.writeTextMessage(message.encode());
        }
    }
}
