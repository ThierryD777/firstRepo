// JavaScript to interact with the Backend via REST and / or WebSockets
const socket = new WebSocket("ws://localhost:8888");

socket.onopen = function() {
    console.log("Connected to WebSocket server");
};

socket.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log("Received:", data);

    if (data.event === "gameStarted") {
        alert("Game has started!");
    } else if (data.event === "playerReady") {
        console.log(`Player ${data.uid} is ready`);
    } else if (data.event === "gameEnded") {
        alert("Game has ended!");
    }
};

function startGame() {
    socket.send(JSON.stringify({ action: "startGame" }));
}

function playerReady(uid) {
    socket.send(JSON.stringify({ action: "playerReady", uid: uid }));
}

function endGame() {
    socket.send(JSON.stringify({ action: "endGame" }));
}